#!/bin/bash
# 1 node
#SBATCH -c 1  
#SBATCH --mem=128G 
#SBATCH --job-name="number-crunching_gprof"
#SBATCH -o "number-crunching_gprof.out"
#SBATCH -e "number-crunching_gprof.err" 
#SBATCH -t 00:15:00 
#SBATCH -p test 

module purge
module load gcc/12.2 likwid/5.2.0
mkdir -p gprof_txt

g++ number_crunching.cpp -fno-inline -fno-reorder-functions -O1 -pg -march=native -o number_crunching_O1
for k in 1 2 3
do
    N=$((k * 10000))
    ./number_crunching_O1 $N
    gprof number_crunching_O1 gmon.out > gprof_txt/gprof_O1_N${N}.txt
    rm -f gmon.out
done

./number_crunching_O1 40000
gprof number_crunching_O1 gmon.out > gprof_txt/number_crunching_gprof.out
rm -f number_crunching_O1
rm -f gmon.out